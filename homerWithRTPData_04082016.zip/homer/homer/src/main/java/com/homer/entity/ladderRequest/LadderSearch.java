package com.homer.entity.ladderRequest;

import java.util.ArrayList;

/**
 * 
 * @author 611022675
 *
 */
public class LadderSearch {
	private String id;
	private String[] callid= {};
	private boolean uniq;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String[] getCallid() {
		return callid;
	}
	public void setCallid(String[] callid) {
		this.callid = callid;
	}
	
	public boolean isUniq() {
		return uniq;
	}
	public void setUniq(boolean uniq) {
		this.uniq = uniq;
	}
	@Override
	public String toString() {
		return "LadderSearch [id=" + id + ", callid=" + callid + ", uniq=" + uniq + "]";
	}
	

}
