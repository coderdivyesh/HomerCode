package com.homer.entity.ladderResponse;

/**
 * 
 * @author 611022675
 *
 */
public class LadderResonseData {
	
	private String status="200";
	private String sid="hoh9djt39b7v2kert87epkala2";
	private boolean auth=true;
	private String message="ok";
	private Data data;
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public boolean isAuth() {
		return auth;
	}
	public void setAuth(boolean auth) {
		this.auth = auth;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "LadderResonseData [status=" + status + ", sid=" + sid + ", auth=" + auth + ", message=" + message
				+ ", data=" + data + "]";
	}
	
	
	

	
	  

}
