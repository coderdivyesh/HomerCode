package test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;


public class TestFile {
public static void main(String[] args) throws FileNotFoundException, IOException {/*

	StringBuilder buildjson = new StringBuilder();
	
	
	try (BufferedReader br = new BufferedReader(
			new FileReader("\\src\\main\\java\\com\\homer\\common\\json\\getdasdBoardStore.json"))) {
		String line;
		while ((line = br.readLine()) != null) {
			buildjson.append(line);
		}
	}
	


*/
	Long l1=1470221454666L;
	Date d1= new Date (l1);
	
	
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

	String DateToStr = format.format(d1); 
        System.out.println(DateToStr); 



}
}
