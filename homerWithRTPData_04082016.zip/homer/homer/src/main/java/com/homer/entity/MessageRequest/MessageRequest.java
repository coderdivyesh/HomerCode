package com.homer.entity.MessageRequest;
/**
 * 
 * @author 611022675
 *
 */
public class MessageRequest {
	
	private Timestamp timestamp;
	private Param param;
	public Timestamp getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}
	public Param getParam() {
		return param;
	}
	public void setParam(Param param) {
		this.param = param;
	}
	@Override
	public String toString() {
		return "SipRtpMessageDetail [timestamp=" + timestamp + ", param=" + param + "]";
	}
	
	

}
