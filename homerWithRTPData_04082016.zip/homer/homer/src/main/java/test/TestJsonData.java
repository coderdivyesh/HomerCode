package test;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;

public class TestJsonData {/*

	public static void main(String[] args) throws Exception {
		
	        Map<String,String> map = new HashMap<>();
	        map.put("key1","value1");
	        map.put("key2","value2");

	        String mapAsJson = new ObjectMapper().writeValueAsString(map);
	        System.out.println(mapAsJson);
	    


	}

*/}
