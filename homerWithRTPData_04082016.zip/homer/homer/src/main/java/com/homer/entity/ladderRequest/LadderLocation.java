package com.homer.entity.ladderRequest;

/**
 * 
 * @author 611022675
 *
 */
public class LadderLocation {

}
