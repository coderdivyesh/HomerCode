package com.homer.entity.ladderRequest;

import java.util.Date;

/**
 * 
 * @author 611022675
 *
 */
public class LadderRequest {
	private LadderTimeStamp timestamp;
	private LadderParam param;
	public LadderTimeStamp getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LadderTimeStamp timestamp) {
		this.timestamp = timestamp;
	}
	public LadderParam getParam() {
		return param;
	}
	public void setParam(LadderParam param) {
		this.param = param;
	}
	@Override
	public String toString() {
		return "LadderRequest [timestamp=" + timestamp + ", param=" + param + "]";
	}
	
	
}
