define({
  "name": "Homer 5 API",
  "version": "2.0.1",
  "description": "sipcapture api",
  "title": "Homer Sipcapture API",
  "url": "http://localhost",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2015-06-18T10:29:36.344Z",
    "url": "http://apidocjs.com",
    "version": "0.13.1"
  }
});