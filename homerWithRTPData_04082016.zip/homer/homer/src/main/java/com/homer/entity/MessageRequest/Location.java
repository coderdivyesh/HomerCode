package com.homer.entity.MessageRequest;

public class Location {
	private String node="single";

	public String getNode() {
		return node;
	}

	public void setNode(String node) {
		this.node = node;
	}

	@Override
	public String toString() {
		return "location [node=" + node + "]";
	}
	

}
