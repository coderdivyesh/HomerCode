package com.homer.entity.data;

import com.homer.common.Utility.Column;

public class SipRtpDataCapture {
	
	
	@Column(name = "PROTOCOL")
	public String protocol;

	@Column(name = "IP_PORT")
	public String ip_port;
	
	@Column(name = "CALL_ID")
	public String call_id;

	@Column(name = "FRAME_NUM")
	public String frame_num;

	@Column(name = "METHOD")
	public String method;

	@Column(name = "ARRIVAL_TIME")
	public String arrival_time;

	@Column(name = "SOURCE_IP")
	public String source_ip;

	@Column(name = "DESTINATION_IP")
	public String destination_ip;

	@Column(name = "SOURCE_PORT")
	public String source_port;

	@Column(name = "DESTINATION_PORT")
	public String destination_port;

	@Column(name = "TYPE_OF_REQUEST")
	public String type_of_request;

	@Column(name = "SOURCE_HOST")
	public String source_host;

	@Column(name = "STATUS_CODE")
	public String status_code;

	@Column(name = "CONTACT")
	public String contact;

	@Column(name = "TO_")
	public String to_;

	@Column(name = "FROM_")
	public String from_;

	@Column(name = "SOURCEPHONENUMBER")
	public String sourcephonenumber;
	
	@Column(name = "DETINATIONPHONENUMBER")
	public String detinationphonenumber;
	
	@Column(name = "MEDIA_DESC")
	public String media_desc;

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getIp_port() {
		return ip_port;
	}

	public void setIp_port(String ip_port) {
		this.ip_port = ip_port;
	}

	public String getCall_id() {
		return call_id;
	}

	public void setCall_id(String call_id) {
		this.call_id = call_id;
	}

	public String getFrame_num() {
		return frame_num;
	}

	public void setFrame_num(String frame_num) {
		this.frame_num = frame_num;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getArrival_time() {
		return arrival_time;
	}

	public void setArrival_time(String arrival_time) {
		this.arrival_time = arrival_time;
	}

	public String getSource_ip() {
		return source_ip;
	}

	public void setSource_ip(String source_ip) {
		this.source_ip = source_ip;
	}

	public String getDestination_ip() {
		return destination_ip;
	}

	public void setDestination_ip(String destination_ip) {
		this.destination_ip = destination_ip;
	}

	public String getSource_port() {
		return source_port;
	}

	public void setSource_port(String source_port) {
		this.source_port = source_port;
	}

	public String getDestination_port() {
		return destination_port;
	}

	public void setDestination_port(String destination_port) {
		this.destination_port = destination_port;
	}

	public String getType_of_request() {
		return type_of_request;
	}

	public void setType_of_request(String type_of_request) {
		this.type_of_request = type_of_request;
	}

	public String getSource_host() {
		return source_host;
	}

	public void setSource_host(String source_host) {
		this.source_host = source_host;
	}

	public String getStatus_code() {
		return status_code;
	}

	public void setStatus_code(String status_code) {
		this.status_code = status_code;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getTo_() {
		return to_;
	}

	public void setTo_(String to_) {
		this.to_ = to_;
	}

	public String getFrom_() {
		return from_;
	}

	public void setFrom_(String from_) {
		this.from_ = from_;
	}

	public String getSourcephonenumber() {
		return sourcephonenumber;
	}

	public void setSourcephonenumber(String sourcephonenumber) {
		this.sourcephonenumber = sourcephonenumber;
	}

	public String getDetinationphonenumber() {
		return detinationphonenumber;
	}

	public void setDetinationphonenumber(String detinationphonenumber) {
		this.detinationphonenumber = detinationphonenumber;
	}

	public String getMedia_desc() {
		return media_desc;
	}

	public void setMedia_desc(String media_desc) {
		this.media_desc = media_desc;
	}

	@Override
	public String toString() {
		return "SipRtpDataCapture [protocol=" + protocol + ", ip_port=" + ip_port + ", call_id=" + call_id
				+ ", frame_num=" + frame_num + ", method=" + method + ", arrival_time=" + arrival_time + ", source_ip="
				+ source_ip + ", destination_ip=" + destination_ip + ", source_port=" + source_port
				+ ", destination_port=" + destination_port + ", type_of_request=" + type_of_request + ", source_host="
				+ source_host + ", status_code=" + status_code + ", contact=" + contact + ", to_=" + to_ + ", from_="
				+ from_ + ", sourcephonenumber=" + sourcephonenumber + ", detinationphonenumber="
				+ detinationphonenumber + ", media_desc=" + media_desc + "]";
	}

	
	

}
