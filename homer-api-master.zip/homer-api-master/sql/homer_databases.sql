CREATE DATABASE homer_data;
CREATE DATABASE homer_configuration;
CREATE DATABASE homer_statistic;
