package com.homer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.homer.entity.User;
import com.homer.entity.Users;
import com.homer.sevice.login.LoginService;

/**
 * 
 * @author 611022675
 *
 */
@RestController
@RequestMapping("/api/v1")



public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	@RequestMapping(value = "/session", method = RequestMethod.POST)
	public ResponseEntity<Users> login(@RequestBody User user) throws Exception  { 
		
		Users users = null;
		users =loginService.loginIn(user);
			return new ResponseEntity<Users>(users, HttpStatus.OK);
		
	}

}
