package com.homer.entity.ladderRequest;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author 611022675
 *
 */
public class LadderRequestBody {

	private String id;
	private List param=new ArrayList();
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List getParam() {
		return param;
	}
	public void setParam(List param) {
		this.param = param;
	}
	@Override
	public String toString() {
		return "LadderRequestBody [id=" + id + ", param=" + param + "]";
	}
	
	

}
