package com.homer.entity.ladderResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author 611022675
 *
 */
public class Info {

	private List callid=new ArrayList();
	private String totdur="00:00:00";
	private String statuscall="1";
	public List getCallid() {
		return callid;
	}
	public void setCallid(List callid) {
		this.callid = callid;
	}
	public String getTotdur() {
		return totdur;
	}
	public void setTotdur(String totdur) {
		this.totdur = totdur;
	}
	public String getStatuscall() {
		return statuscall;
	}
	public void setStatuscall(String statuscall) {
		this.statuscall = statuscall;
	}
	@Override
	public String toString() {
		return "Info [callid=" + callid + ", totdur=" + totdur + ", statuscall=" + statuscall + "]";
	}
	
	
	
	
	
	
	
  
}
