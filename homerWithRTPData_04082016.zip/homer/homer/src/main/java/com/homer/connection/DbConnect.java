package com.homer.connection;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

/**
 * 
 * @author 611022675
 *
 */
public class DbConnect {
    static Properties prop;
    static
    {
        prop = new Properties();
        try {
            prop.load(new FileInputStream("db.properties"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws Exception
    {

        Class.forName(prop.getProperty("driverclass"));
        Connection con = DriverManager.getConnection(prop.getProperty("url"), prop.getProperty("user"), prop.getProperty("password"));

        return con;
    }
}


