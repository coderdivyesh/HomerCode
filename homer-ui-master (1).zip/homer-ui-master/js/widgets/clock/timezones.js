    var timeZoneData = {
	  "UTC/UTC": 0,
	  "Europe/London": 0,
	  "Europe/Amsterdam": 1,
	  "America/Los_Angeles":-8,
	  "America/New_York":-5,
	  "Europe/Moscow":+3,
	  "Asia/Novosibirsk":+6
    };
