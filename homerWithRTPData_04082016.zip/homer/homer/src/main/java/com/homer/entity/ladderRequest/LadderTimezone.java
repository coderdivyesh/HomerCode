package com.homer.entity.ladderRequest;

/**
 * 
 * @author 611022675
 *
 */
public class LadderTimezone {
	
	private String value;
	private String name;
	private String offset;
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOffset() {
		return offset;
	}
	public void setOffset(String offset) {
		this.offset = offset;
	}
	@Override
	public String toString() {
		return "LadderTimezone [value=" + value + ", name=" + name + ", offset=" + offset + "]";
	}
	
	
  

}
