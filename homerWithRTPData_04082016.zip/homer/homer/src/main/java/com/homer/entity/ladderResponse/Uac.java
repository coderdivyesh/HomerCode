package com.homer.entity.ladderResponse;

import java.util.HashMap;
import java.util.Map;
/**
 * 
 * @author 611022675
 *
 */
public class Uac {
	
	private Map<String,UacData> uacMap=new HashMap<String,UacData>();

	public Map<String, UacData> getUacMap() {
		return uacMap;
	}

	public void setUacMap(Map<String, UacData> uacMap) {
		this.uacMap = uacMap;
	}

	@Override
	public String toString() {
		return "Uac [uacMap=" + uacMap + "]";
	}

	
}
