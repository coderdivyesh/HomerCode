package com.homer.service.loginImpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.homer.entity.User;
import com.homer.entity.Users;
import com.homer.sevice.login.LoginService;

/**
 * 
 * @author 611022675
 *
 */
@Service
public class LoginImpl implements LoginService {

	@SuppressWarnings("null")
	@Override
	public Users loginIn(User user) throws Exception {
		Users users = new Users();
		Connection con = null;
		Statement stmt=null;
		boolean flag = false;
		try {
			/*Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@rdl08928dat01-oravip.nat.bt.com:63173:smrtor",
					"otmuser", "d0nk3yk0ng");
			Statement stmt = con.createStatement();*/
			stmt=LoginImpl.dbConnect(con);
			ResultSet rs = stmt.executeQuery("select * from users");
			while (rs.next()) {
				if ((rs.getString(4).equals(user.getUsername())) && (rs.getString(5).equals(user.getPassword()))) {
					// flag=true;
					users.setUUID(rs.getInt(1));
					users.setGID(rs.getInt(2));
					users.setGRP(rs.getString(3));
					users.setUSERNAME(rs.getString(4));
					users.setPASSWORD(rs.getString(5));
					users.setFIRSTNAME(rs.getString(6));
					users.setLASTNAME(rs.getString(7));
					users.setEMAIL(rs.getString(8));
					users.setDEPARTMENT(rs.getString(9));
					users.setREGDATE(rs.getDate(10));
					users.setLASTVISIT(rs.getDate(11));
					users.setACTIVE(rs.getInt(12));

				}
			}

		}

		catch (Exception e) {
			System.out.println(e);
		}

		finally {
			if(null!=con)
			{
			con.close();
			}
		}
		return users;

	}

	public static Statement dbConnect(Connection con) throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@rdl08928dat01-oravip.nat.bt.com:63173:smrtor", "otmuser",
				"d0nk3yk0ng");
		Statement stmt = con.createStatement();
		return(stmt);
	}

}
