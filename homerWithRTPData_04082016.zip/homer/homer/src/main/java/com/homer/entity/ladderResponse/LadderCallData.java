package com.homer.entity.ladderResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author 611022675
 *
 */
public class LadderCallData {

	List<LadderSipCapture> calldata = new ArrayList<LadderSipCapture>();

	public List<LadderSipCapture> getCalldata() {
		return calldata;
	}

	public void setCalldata(List<LadderSipCapture> calldata) {
		this.calldata = calldata;
	}

	@Override
	public String toString() {
		return "LadderResonseData [calldata=" + calldata + "]";
	}
}
