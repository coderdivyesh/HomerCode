package com.homer.entity.ladderResponse;

import com.homer.common.Utility.Column;

/**
 * 
 * @author 611022675
 *
 */

public class RtpInfo{
	
	@Column(name="PROTOCOL")
	private String protocol;
	
	@Column(name="IP_PORT")
	private String ip_port;
	
	@Column(name="FRAMENUMBER")
	private String frameNumber;
	
	@Column(name="ARRIVALTIME")
	private String arrivalTime;
	
	@Column(name="EPOCHTIME")
	private String epochTime;
	
	@Column(name="SOURCEIP")
	private String sourceIp;
	
	@Column(name="DESTINATIONIP")
	private String destinationIp;
	
	@Column(name="SOURCEPORT")
	private String sourcePort;
	
	@Column(name="DESTINATIONPORT")
	private String destinationPort;
	
	@Column(name="PAYLOADTYPE")
	private String payloadType;
	
	@Column(name="SEQUENCE_NUMBER")
	private String sequenceNumber;
	
	@Column(name="TIMESTAMP")
	private String timeStamp;
	
	@Column(name="SYNC_SOURCE_IDEN")
	private String syncSourceIden;
	
	@Column(name="PAYLOAD")
	private String payLoad;
	
	@Column(name="ISOUTOFORDER")
	private String isOutOfOrder;
	
	@Column(name="CALL_ID")
	private String call_id;
	
	public String method_text;
	public String msg_color;
	public int destination;

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getIp_port() {
		return ip_port;
	}

	public void setIp_port(String ip_port) {
		this.ip_port = ip_port;
	}

	public String getFrameNumber() {
		return frameNumber;
	}

	public void setFrameNumber(String frameNumber) {
		this.frameNumber = frameNumber;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getEpochTime() {
		return epochTime;
	}

	public void setEpochTime(String epochTime) {
		this.epochTime = epochTime;
	}

	public String getSourceIp() {
		return sourceIp;
	}

	public void setSourceIp(String sourceIp) {
		this.sourceIp = sourceIp;
	}

	public String getDestinationIp() {
		return destinationIp;
	}

	public void setDestinationIp(String destinationIp) {
		this.destinationIp = destinationIp;
	}

	public String getSourcePort() {
		return sourcePort;
	}

	public void setSourcePort(String sourcePort) {
		this.sourcePort = sourcePort;
	}

	public String getDestinationPort() {
		return destinationPort;
	}

	public void setDestinationPort(String destinationPort) {
		this.destinationPort = destinationPort;
	}

	public String getPayloadType() {
		return payloadType;
	}

	public void setPayloadType(String payloadType) {
		this.payloadType = payloadType;
	}

	public String getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getSyncSourceIden() {
		return syncSourceIden;
	}

	public void setSyncSourceIden(String syncSourceIden) {
		this.syncSourceIden = syncSourceIden;
	}

	public String getPayLoad() {
		return payLoad;
	}

	public void setPayLoad(String payLoad) {
		this.payLoad = payLoad;
	}

	public String getIsOutOfOrder() {
		return isOutOfOrder;
	}

	public void setIsOutOfOrder(String isOutOfOrder) {
		this.isOutOfOrder = isOutOfOrder;
	}

	public String getCall_id() {
		return call_id;
	}

	public void setCall_id(String call_id) {
		this.call_id = call_id;
	}
	
	

	public String getMethod_text() {
		return method_text;
	}

	public void setMethod_text(String method_text) {
		this.method_text = method_text;
	}

	public String getMsg_color() {
		return msg_color;
	}

	public void setMsg_color(String msg_color) {
		this.msg_color = msg_color;
	}

	public int getDestination() {
		return destination;
	}

	public void setDestination(int destination) {
		this.destination = destination;
	}

	@Override
	public String toString() {
		return "RtpInfo [protocol=" + protocol + ", ip_port=" + ip_port + ", frameNumber=" + frameNumber
				+ ", arrivalTime=" + arrivalTime + ", epochTime=" + epochTime + ", sourceIp=" + sourceIp
				+ ", destinationIp=" + destinationIp + ", sourcePort=" + sourcePort + ", destinationPort="
				+ destinationPort + ", payloadType=" + payloadType + ", sequenceNumber=" + sequenceNumber
				+ ", timeStamp=" + timeStamp + ", syncSourceIden=" + syncSourceIden + ", payLoad=" + payLoad
				+ ", isOutOfOrder=" + isOutOfOrder + ", call_id=" + call_id + ", method_text=" + method_text
				+ ", msg_color=" + msg_color + ", destination=" + destination + "]";
	}

	
	
	
}




















/*public class RtpInfo {
	
	public String call_id;
	public String ip_port;
	public String rtp_count;
	public String payload;
	public String direction;
	public String method_text;
	public String msg_color;
	public int destination;
	public String protocol;
	public String source_ip;
	public String destination_ip;
	public String source_port;
	public String destination_port;
	
	
	
	public String getCall_id() {
		return call_id;
	}
	public void setCall_id(String call_id) {
		this.call_id = call_id;
	}
	public String getIp_port() {
		return ip_port;
	}
	public void setIp_port(String ip_port) {
		this.ip_port = ip_port;
	}
	public String getRtp_count() {
		return rtp_count;
	}
	public void setRtp_count(String rtp_count) {
		this.rtp_count = rtp_count;
	}
	public String getPayload() {
		return payload;
	}
	public void setPayload(String payload) {
		this.payload = payload;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getMethod_text() {
		return method_text;
	}
	public void setMethod_text(String method_text) {
		this.method_text = method_text;
	}
	public String getMsg_color() {
		return msg_color;
	}
	public void setMsg_color(String msg_color) {
		this.msg_color = msg_color;
	}
	public int getDestination() {
		return destination;
	}
	public void setDestination(int destination) {
		this.destination = destination;
	}
	public String getProtocol() {
		return protocol;
	}
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	public String getSource_ip() {
		return source_ip;
	}
	public void setSource_ip(String source_ip) {
		this.source_ip = source_ip;
	}
	public String getDestination_ip() {
		return destination_ip;
	}
	public void setDestination_ip(String destination_ip) {
		this.destination_ip = destination_ip;
	}
	public String getSource_port() {
		return source_port;
	}
	public void setSource_port(String source_port) {
		this.source_port = source_port;
	}
	public String getDestination_port() {
		return destination_port;
	}
	public void setDestination_port(String destination_port) {
		this.destination_port = destination_port;
	}
	
	@Override
	public String toString() {
		return "RtpInfo [call_id=" + call_id + ", ip_port=" + ip_port + ", rtp_count=" + rtp_count + ", payload="
				+ payload + ", direction=" + direction + ", method_text=" + method_text + ", msg_color=" + msg_color
				+ ", destination=" + destination + ", protocol=" + protocol + ", source_ip=" + source_ip
				+ ", destination_ip=" + destination_ip + ", source_port=" + source_port + ", destination_port="
				+ destination_port + "]";
	}

}

*/