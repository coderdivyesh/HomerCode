package com.homer.entity.MessageRequest;
/**
 * 
 * @author 611022675
 *
 */
public class Search {
private String id;
private String callid;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getCallid() {
	return callid;
}
public void setCallid(String callid) {
	this.callid = callid;
}
@Override
public String toString() {
	return "search [id=" + id + ", callid=" + callid + "]";
}

}
