package com.homer.sevice.login;

import com.homer.entity.User;
import com.homer.entity.Users;
/**
 * 
 * @author 611022675
 *
 */

public interface LoginService 
{
	public Users loginIn(User user)throws Exception;

}
