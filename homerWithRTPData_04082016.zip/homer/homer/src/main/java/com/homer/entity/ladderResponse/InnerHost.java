package com.homer.entity.ladderResponse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author 611022675
 *
 */
public class InnerHost {
	
	private int position;
	private List<Hosts> hosts=new ArrayList<Hosts>();
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public List<Hosts> getHosts() {
		return hosts;
	}
	public void setHosts(List<Hosts> hosts) {
		this.hosts = hosts;
	}
	@Override
	public String toString() {
		return "InnerHost [position=" + position + ", hosts=" + hosts + "]";
	}

	
	
	
	
	
	
}
