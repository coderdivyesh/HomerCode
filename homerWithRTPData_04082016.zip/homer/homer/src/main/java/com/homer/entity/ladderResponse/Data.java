package com.homer.entity.ladderResponse;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author 611022675
 *
 */
public class Data {

	private Info info;
	private List<OuterHost> hosts=new ArrayList<OuterHost>();
	private List<Uac> uac=new ArrayList<Uac>();
	private List<RtpInfo> rtpinfo=new ArrayList<RtpInfo>();
	List<LadderSipCapture> calldata = new ArrayList<LadderSipCapture>();
	private int count;
	
	public Info getInfo() {
		return info;
	}
	public void setInfo(Info info) {
		this.info = info;
	}
	
	public List<OuterHost> getHosts() {
		return hosts;
	}
	public void setHosts(List<OuterHost> hosts) {
		this.hosts = hosts;
	}
	
	public List<Uac> getUac() {
		return uac;
	}
	public void setUac(List<Uac> uac) {
		this.uac = uac;
	}
	public List<RtpInfo> getRtpinfo() {
		return rtpinfo;
	}
	public void setRtpinfo(List<RtpInfo> rtpinfo) {
		this.rtpinfo = rtpinfo;
	}
	
	public List<LadderSipCapture> getCalldata() {
		return calldata;
	}
	public void setCalldata(List<LadderSipCapture> calldata) {
		this.calldata = calldata;
	}
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "Data [info=" + info + ", hosts=" + hosts + ", uac=" + uac + ", rtpinfo=" + rtpinfo + ", calldata="
				+ calldata + ", count=" + count + "]";
	}
	
	
	
}
