package com.homer.entity.MessageRequest;

/**
 * 
 * @author 611022675
 *
 */
public class Transaction {
	private boolean call;
	private boolean registration;
	private boolean rest;
	public boolean isCall() {
		return call;
	}
	public void setCall(boolean call) {
		this.call = call;
	}
	public boolean isRegistration() {
		return registration;
	}
	public void setRegistration(boolean registration) {
		this.registration = registration;
	}
	public boolean isRest() {
		return rest;
	}
	public void setRest(boolean rest) {
		this.rest = rest;
	}
	@Override
	public String toString() {
		return "Transaction [call=" + call + ", registration=" + registration + ", rest=" + rest + "]";
	}

}
