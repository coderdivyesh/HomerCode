package com.homer.entity.ladderResponse;

/**
 * 
 * @author 611022675
 *
 */
public class UacData {
	
	private String image="sipgateway";
	private String agent="";
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getAgent() {
		return agent;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
	@Override
	public String toString() {
		return "UacData [image=" + image + ", agent=" + agent + "]";
	}

	
}
