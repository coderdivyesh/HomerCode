package com.homer.entity.ladderRequest;

/**
 * 
 * @author 611022675
 *
 */
public class LadderParam {
	private LadderSearch search;
	private LadderLocation location;
	private LadderTransaction transaction;
	private LadderTimezone timezone;
	
	
	public LadderSearch getSearch() {
		return search;
	}


	public void setSearch(LadderSearch search) {
		this.search = search;
	}

	


	

	public LadderLocation getLocation() {
		return location;
	}


	public void setLocation(LadderLocation location) {
		this.location = location;
	}


	public LadderTransaction getTransaction() {
		return transaction;
	}


	public void setTransaction(LadderTransaction transaction) {
		this.transaction = transaction;
	}


	public LadderTimezone getTimezone() {
		return timezone;
	}


	public void setTimezone(LadderTimezone timezone) {
		this.timezone = timezone;
	}


	@Override
	public String toString() {
		return "LadderParam [search=" + search + ", location=" + location + ", transaction=" + transaction
				+ ", timezone=" + timezone + "]";
	}


	
	
	
	
	
	
	
	
}
