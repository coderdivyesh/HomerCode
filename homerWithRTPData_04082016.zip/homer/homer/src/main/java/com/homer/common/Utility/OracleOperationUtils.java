package com.homer.common.Utility;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import com.homer.entity.data.SipCapture;
import com.homer.entity.data.SipRtpDataCapture;
import com.homer.entity.dataTemplate.SearchDataTemplate;
import com.homer.service.loginImpl.LoginImpl;

public class OracleOperationUtils {

	public static SearchDataTemplate select() {
		Statement stmt = null;
		Connection con = null;
		SearchDataTemplate srachdata = new SearchDataTemplate();
		try {
			stmt = LoginImpl.dbConnect(con);
			ResultSet rs = stmt.executeQuery("select PROTOCOL,IP_PORT,CALL_ID,FRAME_NUM,METHOD,ARRIVAL_TIME,SOURCE_IP,DESTINATION_IP,SOURCE_PORT,DESTINATION_PORT,TYPE_OF_REQUEST,SOURCE_HOST,STATUS_CODE,CONTACT,TO_,FROM_,SOURCEPHONENUMBER,DETINATIONPHONENUMBER,MEDIA_DESC from sip_test union select PROTOCOL,IP_PORT,CALL_ID,null as FRAME_NUM, null as METHOD, null as ARRIVAL_TIME, null as SOURCE_IP, null as DESTINATION_IP, null as SOURCE_PORT, null as DESTINATION_PORT, null as TYPE_OF_REQUEST, null as SOURCE_HOST, null as STATUS_CODE, null as CONTACT, null as TO_, null as FROM_, null as SOURCEPHONENUMBER, null as DETINATIONPHONENUMBER, null as MEDIA_DESC from RTP_TEST");
			ArrayList<SipRtpDataCapture> SipRtpDataCapture = new ArrayList<SipRtpDataCapture>();
			while (rs.next()) {
				SipRtpDataCapture siprtpcap = new SipRtpDataCapture();
				Field fields[] = SipRtpDataCapture.class.getFields();
				for (Field field : fields) {
					String fieldname = field.getAnnotation(Column.class).name();
					field.setAccessible(Boolean.TRUE);
					if (field.getType().isAssignableFrom(String.class)) {
						field.set(siprtpcap, rs.getString(fieldname));
					} else if (field.getType().isAssignableFrom(Integer.class)) {
						field.set(siprtpcap, rs.getInt(fieldname));
					} else if (field.getType().isAssignableFrom(Double.class)) {
						field.set(siprtpcap, rs.getDouble(fieldname));
					} else if (field.getType().isAssignableFrom(Long.class)) {
						field.set(siprtpcap, rs.getLong(fieldname));
					} else if (field.getType().isAssignableFrom(Character.class)) {
						field.set(siprtpcap, rs.getLong(fieldname));
					} else if (field.getType().isAssignableFrom(Float.class)) {
						field.set(siprtpcap, rs.getLong(fieldname));
					} else if (field.getType().isAssignableFrom(Date.class)) {
						java.util.Date utildate = rs.getTimestamp(fieldname);
						field.set(siprtpcap, utildate);
					}
				}
				SipRtpDataCapture.add(siprtpcap);
			}
			srachdata.setData(SipRtpDataCapture);
		}

		catch (Exception e) {
			System.out.println("Exception from data selection from OracleOperationUtils" + e);
		}
		return srachdata;
	}

}
