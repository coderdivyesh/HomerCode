package com.homer.service.dataImpl;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.homer.common.Utility.Column;
import com.homer.common.Utility.ColumnValue;
import com.homer.common.Utility.OracleOperationUtils;
import com.homer.entity.MessageRequest.MessageRequest;
import com.homer.entity.MessageRequest.Param;
import com.homer.entity.MessageRequest.Search;
import com.homer.entity.MessageResponse.MessageDataResponse;
import com.homer.entity.MessageResponse.MsgData;
import com.homer.entity.data.SipCapture;
import com.homer.entity.dataTemplate.SearchDataTemplate;
import com.homer.entity.ladderRequest.LadderParam;
import com.homer.entity.ladderRequest.LadderRequest;
import com.homer.entity.ladderRequest.LadderSearch;
import com.homer.entity.ladderResponse.Data;
import com.homer.entity.ladderResponse.Hosts;
import com.homer.entity.ladderResponse.InnerHost;
import com.homer.entity.ladderResponse.LadderResonseData;
import com.homer.entity.ladderResponse.LadderSipCapture;
import com.homer.entity.ladderResponse.OuterHost;
import com.homer.entity.ladderResponse.RtpInfo;
import com.homer.entity.ladderResponse.Uac;
import com.homer.entity.ladderResponse.UacData;
import com.homer.service.data.DataService;
import com.homer.service.loginImpl.LoginImpl;

/**
 * 
 * @author 611022675
 *
 */
@Service
public class DataServiceImpl implements DataService {

	@Override
	public StringBuilder getdasdBoardStore() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/getdasdBoardStore.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	@Override
	public StringBuilder getdasdBoardStoreHome() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/getdashboardStoreHome.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	@Override
	public StringBuilder getstatisticMethod() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/getstatisticMethod.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	@Override
	public StringBuilder getdashBoardNode() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/getdashBoardNode.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	@Override
	public StringBuilder getdashBoardHome() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/getdashboardHome.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	@Override
	public StringBuilder getTimeRange() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/getTimeRange.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	@Override
	public StringBuilder getProfileStore() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/getProfileStore.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	@Override
	public SearchDataTemplate getsearchData() throws Exception {

		SearchDataTemplate sdt = OracleOperationUtils.select();
		return sdt;

		/*
		 * StringBuilder buildjson = new StringBuilder(); try (BufferedReader br
		 * = new BufferedReader( new FileReader(
		 * "C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/data.json"
		 * ))) { String line; while ((line = br.readLine()) != null) {
		 * buildjson.append(line); } } return buildjson;
		 * 
		 */}

	@Override
	public StringBuilder getTransactionData() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/transactiondata.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	@Override
	public StringBuilder getResultData() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/transactiondata.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	@Override
	public StringBuilder getNodeData() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/transactiondata.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	/**
	 * for showing the ladder
	 * 
	 * @return
	 * @throws Exception
	 */
	@Override
	public LadderResonseData getSearchTransactionData(LadderRequest ladderRequest) throws Exception {

		Statement stmt = null;
		Connection con = null;
		LadderParam param = ladderRequest.getParam();
		LadderSearch search = param.getSearch();
		String id = search.getId();
		String[] callidArray = search.getCallid();
		String callid = callidArray[0];
		LadderResonseData ladderResposeData = new LadderResonseData();
		Data data = new Data();
		
		
		
		stmt = LoginImpl.dbConnect(con);
		ResultSet rs = stmt.executeQuery("select * from sip_test where CALL_ID='" + callid + "'");
		ArrayList<LadderSipCapture> spicapture = new ArrayList<LadderSipCapture>();
		while (rs.next()) {

			LadderSipCapture spicap = new LadderSipCapture();
			Field fields[] = LadderSipCapture.class.getFields();

			for (Field field : fields) {

				if (field.getName().equals("method_text") || field.getName().equals("msg_color")
						|| field.getName().equals("destination") || field.getName().equals("src_id")
						|| field.getName().equals("dst_id")) {
					break;
				}

				String fieldname = null;
				if (null != field.getAnnotation(Column.class)) {
					fieldname = field.getAnnotation(Column.class).name();
				}
				String value = null;
				if (null != field.getAnnotation(ColumnValue.class)) {
					value = field.getAnnotation(ColumnValue.class).value();
				}
				field.setAccessible(Boolean.TRUE);
				if (field.getName().equals("node") || field.getName().equals("dbnode")) {
					field.set(spicap, value);
				}

				if (field.getType().isAssignableFrom(String.class)) {
					if (!(field.getName().equals("node") || field.getName().equals("dbnode"))) {
						field.set(spicap, rs.getString(fieldname));
					}
				} else if (field.getType().isAssignableFrom(Integer.class)) {
					field.set(spicap, rs.getInt(fieldname));
				} else if (field.getType().isAssignableFrom(Double.class)) {
					field.set(spicap, rs.getDouble(fieldname));
				} else if (field.getType().isAssignableFrom(Long.class)) {
					field.set(spicap, rs.getLong(fieldname));
				} else if (field.getType().isAssignableFrom(Character.class)) {
					field.set(spicap, rs.getLong(fieldname));
				} else if (field.getType().isAssignableFrom(Float.class)) {
					field.set(spicap, rs.getLong(fieldname));
				} else if (field.getType().isAssignableFrom(Date.class)) {
					java.util.Date utildate = rs.getTimestamp(fieldname);
					field.set(spicap, utildate);
				}
			}

			if (spicap.getMethod().equalsIgnoreCase("INVITE")) {
				spicap.setMethod_text("INVITE  (SDP)");
				spicap.setMsg_color("blue");
				spicap.setDestination(1);
			} else if (spicap.getMethod().equalsIgnoreCase("180")) {
				spicap.setMethod_text("180 Ringing");
				spicap.setMsg_color("blue");
				spicap.setDestination(2);
			}else if (spicap.getMethod().equalsIgnoreCase("ACK")) {
				spicap.setMethod_text("ACK");
				spicap.setMsg_color("blue");
				spicap.setDestination(1);
			} else if (spicap.getMethod().equalsIgnoreCase("200")) {

				if (null != spicap.getStatus_code() && spicap.getCseq().contains("INVITE")) {
					spicap.setMethod_text("200 OK(SDP)");
					spicap.setMsg_color("green");
					spicap.setDestination(2);
				} else if(null != spicap.getStatus_code() && spicap.getCseq().contains("BYE")) {
					spicap.setMethod_text("200 OK");
					spicap.setMsg_color("green");
					spicap.setDestination(1);
				}
				
			}
			
			else if (spicap.getMethod().equalsIgnoreCase("BYE")) {
					spicap.setMethod_text("BYE");
					spicap.setMsg_color("blue");
					spicap.setDestination(2);
			}

			spicap.setSrc_id(spicap.getSource_ip() + ":" + spicap.getSource_port());
			spicap.setDst_id(spicap.getDestination_ip() + ":" + spicap.getDestination_port());

			spicapture.add(spicap);
		}

		data.setCalldata(spicapture);
		setDataHost(data, callid);
		setRTPData(data, callid);
		ladderResposeData.setData(data);
		// ladderResposeData.getCalldata().addAll(spicapture);
		
		return ladderResposeData;

	}

	public void setDataHost(Data data, String callid) throws Exception {
		OuterHost outerHost = new OuterHost();
		InnerHost innerHost = new InnerHost();
		InnerHost innerHost2 = new InnerHost();
		Hosts hosts1 = new Hosts();
		Hosts hosts2 = new Hosts();
		Statement stmt = null;
		Connection con = null;
		stmt = LoginImpl.dbConnect(con);
		ResultSet rs = stmt.executeQuery(
				"select distinct source_ip,source_port,destination_ip,destination_port from sip_test where CALL_ID='"
						+ callid + "'  and rownum= 1  ");

		String caller = new String();
		String reveciver = new String();

		while (rs.next()) {
			caller = rs.getString("source_ip") + ":" + rs.getString("source_port");
			reveciver = rs.getString("destination_ip") + ":" + rs.getString("destination_port");
		}

		Map<String, InnerHost> m = new HashMap<String, InnerHost>();

		Map<String, String> host1Map = new HashMap<String, String>();

		List<Hosts> host1List = new ArrayList<Hosts>();

		host1Map.put(caller, "0");
		hosts1.setHosts(host1Map);
		host1List.add(hosts1);

		innerHost.setPosition(0);
		innerHost.setHosts(host1List);

		Map<String, String> host2Map = new HashMap<String, String>();
		List<Hosts> host2List = new ArrayList<Hosts>();
		host2Map.put(reveciver, "1");
		hosts2.setHosts(host2Map);
		host2List.add(hosts2);

		innerHost2.setPosition(1);
		innerHost2.setHosts(host2List);

		m.put(caller, innerHost);
		m.put(reveciver, innerHost2);

		outerHost.setHosts(m);

		List<OuterHost> ll = new ArrayList<OuterHost>();
		ll.add(outerHost);

		Map<String, UacData> uacMap = new HashMap<String, UacData>();
		Map<String, UacData> uacMap2 = new HashMap<String, UacData>();

		Uac uac1 = new Uac();
		Uac uac2 = new Uac();
		UacData uacdata1 = new UacData();
		uacMap.put(caller, uacdata1);
		uacMap2.put(reveciver, uacdata1);

		uac1.setUacMap(uacMap);
		uac2.setUacMap(uacMap2);
		List<Uac> listuac = new ArrayList<Uac>();

		listuac.add(uac1);
		listuac.add(uac2);

		data.setUac(listuac);

		data.setHosts(ll);

	}

	@Override
	public StringBuilder getQosData() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/QOSData.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	@Override
	public StringBuilder getReportLogData() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/logReport.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	@Override
	public StringBuilder getReportRtcData() throws Exception {
		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader(
				"C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/logReport.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return buildjson;

	}

	@Override
	public MessageDataResponse getMessageData(MessageRequest messageRequest) throws Exception {

		Statement stmt = null;
		Connection con = null;
		Param param = messageRequest.getParam();
		Search search = param.getSearch();
		String callid = search.getCallid();
		String frame_number=search.getId();
		stmt = LoginImpl.dbConnect(con);
		MessageDataResponse messageDataResponse = new MessageDataResponse();
		
		String protocolCheck=checkSiporRtp(stmt,frame_number,callid);
		if(protocolCheck.equals("SIP"))
		
		{
		ResultSet rs = stmt.executeQuery("select * from sip_test where CALL_ID='" + callid + "' and FRAME_NUM='" + frame_number + "' ");
		
		MsgData data = new MsgData();
		List<MsgData> msgDataList = new ArrayList<MsgData>();		
		while (rs.next()) {

			SipCapture spicap = new SipCapture();
			Field fields[] = SipCapture.class.getFields();
			for (Field field : fields) {

				String fieldname = null;
				if (null != field.getAnnotation(Column.class)) {
					fieldname = field.getAnnotation(Column.class).name();
				}
				String value = null;
				if (null != field.getAnnotation(ColumnValue.class)) {
					value = field.getAnnotation(ColumnValue.class).value();
				}
				field.setAccessible(Boolean.TRUE);
				if (field.getName().equals("node") || field.getName().equals("dbnode")) {
					field.set(spicap, value);
				}

				if (field.getType().isAssignableFrom(String.class)) {
					if (!(field.getName().equals("node") || field.getName().equals("dbnode"))) {
						field.set(spicap, rs.getString(fieldname));
					}
				} else if (field.getType().isAssignableFrom(Integer.class)) {
					field.set(spicap, rs.getInt(fieldname));
				} else if (field.getType().isAssignableFrom(Double.class)) {
					field.set(spicap, rs.getDouble(fieldname));
				} else if (field.getType().isAssignableFrom(Long.class)) {
					field.set(spicap, rs.getLong(fieldname));
				} else if (field.getType().isAssignableFrom(Character.class)) {
					field.set(spicap, rs.getLong(fieldname));
				} else if (field.getType().isAssignableFrom(Float.class)) {
					field.set(spicap, rs.getLong(fieldname));
				} else if (field.getType().isAssignableFrom(Date.class)) {
					java.util.Date utildate = rs.getTimestamp(fieldname);
					field.set(spicap, utildate);
				}
			}

			data.setSipcapture(spicap);
			String mediadesc=data.getSipcapture().getMedia_desc();
			mediadesc.replaceAll("/", "\\/");
			String outputdata=getUpdateMessage(data,callid,frame_number);
			String finalMedia=outputdata+"\r\n"+mediadesc;
			data.getSipcapture().setMedia_desc(finalMedia);
			msgDataList.add(data);
			messageDataResponse.setData(msgDataList);
		}
	}
		else{
			ResultSet rs = stmt.executeQuery("select * from rtp_test where CALL_ID='" + callid + "' and FRAMENUMBER='" + frame_number + "' ");
			
			MsgData data = new MsgData();
			List<MsgData> msgDataList = new ArrayList<MsgData>();		
			while (rs.next()) {

				RtpInfo rtpInfo=new RtpInfo();
				Field fields[] = RtpInfo.class.getDeclaredFields();
				for (Field field : fields) {

					if (field.getName().equals("method_text")||field.getName().equals("msg_color")||field.getName().equals("destination"))
					{
						break;
					}
					String fieldname = null;
					if (null != field.getAnnotation(Column.class)) {
						fieldname = field.getAnnotation(Column.class).name();
					}
					String value = null;
					if (null != field.getAnnotation(ColumnValue.class)) {
						value = field.getAnnotation(ColumnValue.class).value();
					}
					field.setAccessible(Boolean.TRUE);
					if (field.getName().equals("node") || field.getName().equals("dbnode")) {
						field.set(rtpInfo, value);
					}

					if (field.getType().isAssignableFrom(String.class)) {
						if (!(field.getName().equals("node") || field.getName().equals("dbnode"))) {
							field.set(rtpInfo, rs.getString(fieldname));
						}
					} else if (field.getType().isAssignableFrom(Integer.class)) {
						field.set(rtpInfo, rs.getInt(fieldname));
					} else if (field.getType().isAssignableFrom(Double.class)) {
						field.set(rtpInfo, rs.getDouble(fieldname));
					} else if (field.getType().isAssignableFrom(Long.class)) {
						field.set(rtpInfo, rs.getLong(fieldname));
					} else if (field.getType().isAssignableFrom(Character.class)) {
						field.set(rtpInfo, rs.getLong(fieldname));
					} else if (field.getType().isAssignableFrom(Float.class)) {
						field.set(rtpInfo, rs.getLong(fieldname));
					} else if (field.getType().isAssignableFrom(Date.class)) {
						java.util.Date utildate = rs.getTimestamp(fieldname);
						field.set(rtpInfo, utildate);
					}
				}

				data.setRtpData(rtpInfo);
			/*	String mediadesc=data.getSipcapture().getMedia_desc();
				mediadesc.replaceAll("/", "\\/");
				String outputdata=getUpdateMessage(data,callid,frame_number);
				String finalMedia=outputdata+"\r\n"+mediadesc;
				data.getSipcapture().setMedia_desc(finalMedia);*/
				msgDataList.add(data);
				messageDataResponse.setData(msgDataList);
			}
		}
		return messageDataResponse;
	}
	
	
	public String checkSiporRtp(Statement stmt,String frame_number, String callid) throws SQLException, IllegalArgumentException, IllegalAccessException
	{
		String protocol=null;
		ResultSet rs = stmt.executeQuery("select FRAME_NUM from sip_test where CALL_ID='" + callid + "'");
		while (rs.next()) {
			SipCapture spicap = new SipCapture();
			Field fields[] = SipCapture.class.getDeclaredFields();
			for (Field field : fields) {

				String fieldname = null;
				if (null != field.getAnnotation(Column.class)) {
					fieldname = field.getAnnotation(Column.class).name();
				}
				if(fieldname.equals("FRAME_NUM"))
				{
					String frameNum=rs.getString(fieldname);
					if(frameNum.equals(frame_number))
					{
						protocol="SIP";
						break;
					}
				}

		
			}
			
		}
		
		if(null==protocol)
		{
			ResultSet result = stmt.executeQuery("select FRAMENUMBER from rtp_test where CALL_ID='" + callid + "'");
			while (result.next()) {
				Field fields[] = RtpInfo.class.getDeclaredFields();
				for (Field field : fields) {
					
					if(field.getName().equals("method_text") || field.getName().equals("msg_color")||field.getName().equals("destination"))
					{
						break;
					}
					String fieldname = null;
					if (null != field.getAnnotation(Column.class)) {
						fieldname = field.getAnnotation(Column.class).name();
					}
					if(fieldname.equals("FRAMENUMBER"))
					{
						String frameNum=result.getString(fieldname);
						if(frameNum.equals(frame_number))
						{
							protocol="RTP";
							break;
						}
					}

			
				}
				
			}
		}
		
		return protocol;
		
	}
	
	
	public String getUpdateMessage(MsgData data,String callid,String frame_number) throws Exception{
		Statement stmt = null;
		Connection con = null;
		stmt = LoginImpl.dbConnect(con);
		String outputdata=new String();
		
		String reqType=data.getSipcapture().getType_of_request();
		reqType.replaceAll("/", "\\/");
		
		
		String reqURI=data.getSipcapture().getRequesturi();
		reqURI.replaceAll("/", "\\/");
		
		String via=data.getSipcapture().getVia();
		via.replaceAll("/", "\\/");
		
		
		String from=data.getSipcapture().getFrom_();
		from.replaceAll("/", "\\/");
		
		
		String todata=data.getSipcapture().getTo_();
		todata.replaceAll("/", "\\/");
		
		String calliddata=data.getSipcapture().getCall_id();
		calliddata.replaceAll("/", "\\/");
		
		String CSeq=data.getSipcapture().getCseq();
		CSeq.replaceAll("/", "\\/");
		
		String Contact=data.getSipcapture().getContact();
		Contact.replaceAll("/", "\\/");
		
		String Max_Forwards=data.getSipcapture().getMax_fordwords();
		Max_Forwards.replaceAll("/", "\\/");
		
		String ContentType=data.getSipcapture().getContent_type();
		ContentType.replaceAll("/", "\\/");
		
		String Contentlenght=data.getSipcapture().getContent_length();
		Contentlenght.replaceAll("/", "\\/");
		
		outputdata=reqType+" "+reqURI+"\r\n"+"Via :"+via+"\r\n"+"From :"+from+"\r\n"+"To :"+todata+"\r\n"+"Call-ID :"+calliddata+"\r\n"+"CSeq :"+CSeq+"\r\n"+"Contact :"+Contact+"\r\n"+"Max-Forwards :"+Max_Forwards+"\r\n"+"Content-Type :"+ContentType+"\r\n"+"Content-Length :"+Contentlenght+"\r\n";
		
		ResultSet rs = stmt.executeQuery("select metric_id,metric_value from call_metric where CALL_ID='" + callid + "' order by metric_id asc");
		int number = 0;
		
		while (rs.next()) {
			String s1=rs.getString("metric_value");
			s1.replaceAll("/", "\\/");
			if(number==0){
				outputdata=outputdata+"AVG_JITTER :"+s1 +"\r\n";
			}
			else if(number==1){
				outputdata=outputdata+"MIN_JITTER :"+s1 +"\r\n";
			}
			else if(number==2){
				outputdata=outputdata+"CALL_DURATION :"+s1 +"\r\n";
			}
			else if(number==3){
				outputdata=outputdata+"CONNECT_LATENCY :"+s1 +"\r\n";
			}
			else if(number==4){
				outputdata=outputdata+"PACKET_LOST :"+s1 +"\r\n";
			}
			else if(number==5){
				outputdata=outputdata+"PACKET_SENT :"+s1 +"\r\n";
			}
			else if(number==6){
				outputdata=outputdata+"PACKET_RECEIVED :"+s1 +"\r\n";
			}
			else if(number==7){
				outputdata=outputdata+"MAX_JITTER :"+s1 +"\r\n";
			}
			else if(number==8){
				outputdata=outputdata+"PACKET_OOS :"+s1 +"\r\n";
			}
			else if(number==9){
				outputdata=outputdata+"MOS :"+s1 +"\r\n";
			}
			else if(number==10){
				outputdata=outputdata+"R_FACTOR :"+s1 +"\r\n";
			}
			number++;
		}
		
		
		return outputdata;
	}
	

	
	public void setRTPData(Data data,String callId) throws Exception{
		
		List<RtpInfo> rtpInfo = new ArrayList<RtpInfo>();
		RtpInfo rtpInfo1=new RtpInfo();
		RtpInfo rtpInfo2=new RtpInfo();
		
		Statement stmt = null;
		Connection con = null;
		stmt = LoginImpl.dbConnect(con);
		ResultSet rs = stmt.executeQuery("select distinct ip_port,payloadtype,count(*) from rtp_test where  CALL_ID='" + callId + "' group by ip_port,payloadtype ");
		boolean setDestination=true;
		while (rs.next()) {
		ArrayList<RtpInfo> rtpData = new ArrayList<RtpInfo>();
		LadderSipCapture spicap = new LadderSipCapture();
		RtpInfo ladderRtp = new RtpInfo();
		Field fields[] = RtpInfo.class.getDeclaredFields();
		
		for (Field field : fields) {

			/*if (field.getName().equals("method_text") || field.getName().equals("msg_color")
					|| field.getName().equals("destination") || field.getName().equals("src_id")
					|| field.getName().equals("dst_id")) {
				break;
			}*/
			
				if (field.getName().equals("method_text")) {
					field.set(ladderRtp, "RTP (OK)");
					break;

				} else if (field.getName().equals("msg_color")) {

					field.set(ladderRtp, "red");
					break;

				}else if(field.getName().equals("destination"))
				{
					if(setDestination)
					{
						field.set(ladderRtp, "0");
						setDestination=false;
						break;
					}
					else
					{
						field.set(ladderRtp, "1");
						setDestination=true;
						break;
					}
						
				}
					

			String fieldname = null;
			if (null != field.getAnnotation(Column.class)) {
				fieldname = field.getAnnotation(Column.class).name();
			}
			String value = null;
			if (null != field.getAnnotation(ColumnValue.class)) {
				value = field.getAnnotation(ColumnValue.class).value();
			}
			field.setAccessible(Boolean.TRUE);
			/*if (field.getName().equals("node") || field.getName().equals("dbnode")) {
				field.set(ladderRtp, value);
			}*/
			
			
			if(fieldname.equals("IP_PORT")||fieldname.equals("PAYLOADTYPE"))
			{
				if (field.getType().isAssignableFrom(String.class)) {
					field.set(ladderRtp, rs.getString(fieldname));
				} else if (field.getType().isAssignableFrom(Integer.class)) {
					field.set(ladderRtp, rs.getInt(fieldname));
				} else if (field.getType().isAssignableFrom(Double.class)) {
					field.set(ladderRtp, rs.getDouble(fieldname));
				} else if (field.getType().isAssignableFrom(Long.class)) {
					field.set(ladderRtp, rs.getLong(fieldname));
				} else if (field.getType().isAssignableFrom(Character.class)) {
					field.set(ladderRtp, rs.getLong(fieldname));
				} else if (field.getType().isAssignableFrom(Float.class)) {
					field.set(ladderRtp, rs.getLong(fieldname));
				} else if (field.getType().isAssignableFrom(Date.class)) {
					java.util.Date utildate = rs.getTimestamp(fieldname);
					field.set(ladderRtp, utildate);
				}
				
			}
			else
				continue;
		
		}
		
		rtpInfo.add(ladderRtp);
		
		}
		
		data.setRtpinfo(rtpInfo);
	}
	
	/*List<RtpInfo> rtpInfo = new ArrayList<RtpInfo>();
	RtpInfo rt1=new RtpInfo();
	RtpInfo rt2=new RtpInfo();
	
	rt1.setCall_id("AA");
	rt1.setProtocol("RTP");
	rt1.setIp_port("172.25.182.172:5060");
	rt1.setSource_ip("10.109.115.69:5060");
	rt1.setDestination_ip("172.25.182.172:5060");
	rt1.setMethod_text("RTP (OK)");
	rt1.setMsg_color("red");
	rt1.setDestination(0);
	
	
	rt2.setCall_id("AA");
	rt2.setProtocol("RTP");
	rt2.setIp_port("172.25.182.172:5060");
	rt2.setSource_ip("10.109.115.69:5060");
	rt2.setDestination_ip("10.109.115.69:5060");
	rt2.setMethod_text("RTP (OK)");
	rt2.setMsg_color("red");
	rt2.setDestination(0);
	
	rtpInfo.add(rt1);
	rtpInfo.add(rt2);
	
	data.setRtpinfo(rtpInfo);
	*/
	
	

}



