package com.homer.entity.ladderResponse;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author 611022675
 *
 */
public class OuterHost {
	
	private Map<String,InnerHost> hosts=new HashMap<String,InnerHost>();

	public Map<String, InnerHost> getHosts() {
		return hosts;
	}

	public void setHosts(Map<String, InnerHost> hosts) {
		this.hosts = hosts;
	}

	@Override
	public String toString() {
		return "OuterHost [hosts=" + hosts + "]";
	}

	
	
	
}
