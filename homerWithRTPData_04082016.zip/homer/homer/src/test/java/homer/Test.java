package homer;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;

public class Test {

    @SuppressWarnings("unchecked")
    public static void main(String[] args) {

      Map<String, Object> map = new HashMap<String, Object>();
      map.put("1", "a");
      map.put("2", "b");

      //System.out.println(new JSONObject().;

    //  Map<String, Object> newMap = (Map<String, Object>) $.fromJson($.toJson(map));         
    //  System.out.println(newMap.get("1"));

    }

}
