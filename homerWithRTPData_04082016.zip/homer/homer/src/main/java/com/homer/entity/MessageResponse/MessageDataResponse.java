package com.homer.entity.MessageResponse;

import java.util.ArrayList;
import java.util.List;

public class MessageDataResponse {
	private String status = "200";
	private String sid = "7sc61phho9nvfvlkpfmun5qjd2";
	private String auth = "true";
	private String message = "ok";
	private List<MsgData> data = new ArrayList<MsgData>();
	private String count;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getAuth() {
		return auth;
	}
	public void setAuth(String auth) {
		this.auth = auth;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<MsgData> getData() {
		return data;
	}
	public void setData(List<MsgData> data) {
		this.data = data;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "MessageDataResponse [status=" + status + ", sid=" + sid + ", auth=" + auth + ", message=" + message
				+ ", data=" + data + ", count=" + count + "]";
	}
	
	

}
