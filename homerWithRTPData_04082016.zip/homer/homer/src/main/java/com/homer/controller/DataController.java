package com.homer.controller;

import java.io.BufferedReader;
import java.io.FileReader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.homer.entity.MessageRequest.MessageRequest;
import com.homer.entity.MessageResponse.MessageDataResponse;
import com.homer.entity.dataTemplate.SearchDataTemplate;
import com.homer.entity.ladderRequest.LadderRequest;
import com.homer.entity.ladderResponse.LadderResonseData;
import com.homer.service.data.DataService;

/**
 * 
 * @author 611022675
 *
 */
@RestController
@RequestMapping("/api/v1")
public class DataController {
	
	@Autowired 
	DataService dataService;
	
	
	@RequestMapping(value = "/dashboard/store", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> dashBoardStore() throws Exception
	{
		StringBuilder jsontext=dataService.getdasdBoardStore() ;
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/dashboard/store/home", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> dashBoardStoreHome() throws Exception
	{
		StringBuilder jsontext=dataService.getdasdBoardStoreHome();
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/statistic/method", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> statisticMethod() throws Exception
	{
		StringBuilder jsontext=dataService.getstatisticMethod();
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/dashboard/node", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> dashBoardNode() throws Exception
	{
		StringBuilder jsontext=dataService.getstatisticMethod();
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/dashboard/home", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> dashBoardHome() throws Exception
	{
		StringBuilder jsontext=dataService.getdashBoardHome();
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/profile/store/timerange", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> profileTimeRange() throws Exception
	{
		StringBuilder jsontext=dataService.getTimeRange();
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/profile/store", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> profileStore() throws Exception
	{
		StringBuilder jsontext=dataService.getProfileStore();
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/search/data", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<SearchDataTemplate> searchData() throws Exception
	{
		//StringBuilder jsontext=dataService.getsearchData();
		SearchDataTemplate searchedData=dataService.getsearchData();
		return new ResponseEntity<SearchDataTemplate>(searchedData, HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/profile/store/transaction", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> transactionData() throws Exception
	{
		StringBuilder jsontext=dataService.getTransactionData();
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/profile/store/result", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> resultData() throws Exception
	{
		StringBuilder jsontext=dataService.getResultData();
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/profile/store/node", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> nodeData() throws Exception
	{
		StringBuilder jsontext=dataService.getNodeData();
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}
	
	
	/**
	 * this call get executes when we click on call id to get ladder
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/search/transaction", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE,consumes =MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<LadderResonseData> searchTransaction(@RequestBody LadderRequest ladderRequest) throws Exception
	{

		LadderResonseData ladderResposeData=dataService.getSearchTransactionData(ladderRequest);
		return new ResponseEntity<LadderResonseData>(ladderResposeData, HttpStatus.OK);
		
	}
	
	/*@RequestMapping(value = "/search/transaction", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE,consumes =MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> searchTransaction(@RequestBody LadderRequest ladderRequest) throws Exception
	{

		StringBuilder buildjson = new StringBuilder();
		try (BufferedReader br = new BufferedReader(
				new FileReader("C:/HomerSVNRepo/VoiceGUI/homer/homer/src/main/java/com/homer/common/json/searchTransactionData.json"))) {
			String line;
			while ((line = br.readLine()) != null) {
				buildjson.append(line);
			}
		}
		return new ResponseEntity<Object>(buildjson.toString().trim(), HttpStatus.OK);

	
		
		
	}*/

	
	@RequestMapping(value = "/report/qos", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> qosData() throws Exception
	{
		StringBuilder jsontext=dataService.getQosData();
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/report/log", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> reportLogData() throws Exception
	{
		StringBuilder jsontext=dataService.getReportLogData();
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/report/rtc", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> reportRtcData() throws Exception
	{
		StringBuilder jsontext=dataService.getReportRtcData();
		return new ResponseEntity<Object>(jsontext.toString().trim(), HttpStatus.OK);
		
	}

	@RequestMapping(value = "/search/method", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE,consumes =MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<MessageDataResponse> messageSearchData(@RequestBody MessageRequest messageRequest) throws Exception
	{
		
		MessageDataResponse messageDataResponse = dataService.getMessageData( messageRequest);
		return new ResponseEntity<MessageDataResponse>(messageDataResponse, HttpStatus.OK);
		
	}




}
