package com.homer.entity.MessageResponse;

import com.homer.entity.data.SipCapture;
import com.homer.entity.ladderResponse.RtpInfo;

public class MsgData {
	private SipCapture sipcapture;
	private RtpInfo rtpData;

	public SipCapture getSipcapture() {
		return sipcapture;
	}

	public void setSipcapture(SipCapture sipcapture) {
		this.sipcapture = sipcapture;
	}

	public RtpInfo getRtpData() {
		return rtpData;
	}

	public void setRtpData(RtpInfo rtpData) {
		this.rtpData = rtpData;
	}

	@Override
	public String toString() {
		return "MsgData [sipcapture=" + sipcapture + ", rtpData=" + rtpData + "]";
	}

	

}
