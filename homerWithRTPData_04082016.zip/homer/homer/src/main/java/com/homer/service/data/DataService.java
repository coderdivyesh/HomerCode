package com.homer.service.data;

import com.homer.entity.MessageRequest.MessageRequest;
import com.homer.entity.MessageResponse.MessageDataResponse;
import com.homer.entity.dataTemplate.SearchDataTemplate;
import com.homer.entity.ladderRequest.LadderRequest;
import com.homer.entity.ladderResponse.LadderResonseData;

/**
 * 
 * @author 611022675
 *
 */
public interface DataService {
	
	public StringBuilder getdasdBoardStore() throws Exception;
	
	public StringBuilder getdasdBoardStoreHome() throws Exception;
	
	public StringBuilder getstatisticMethod() throws Exception;
	
	public StringBuilder getdashBoardNode() throws Exception;
	
	public StringBuilder getdashBoardHome() throws Exception;
	
	public StringBuilder getTimeRange() throws Exception;

	public StringBuilder getProfileStore() throws Exception;

	public SearchDataTemplate getsearchData()throws Exception;

	public StringBuilder getTransactionData() throws Exception;

	public StringBuilder getResultData() throws Exception;

	public StringBuilder getNodeData() throws Exception;

	public LadderResonseData getSearchTransactionData(LadderRequest ladderRequest) throws Exception;

	public StringBuilder getQosData() throws Exception;

	public StringBuilder getReportLogData()throws Exception;

	public StringBuilder getReportRtcData() throws Exception;

	public MessageDataResponse getMessageData(MessageRequest messageRequest)throws Exception;
	
	
}
