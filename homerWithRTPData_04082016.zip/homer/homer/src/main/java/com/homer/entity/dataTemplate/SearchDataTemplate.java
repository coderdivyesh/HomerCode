package com.homer.entity.dataTemplate;

import java.util.ArrayList;

import com.homer.entity.data.SipCapture;
import com.homer.entity.data.SipRtpDataCapture;

/**
 * 
 * @author 611022675
 *
 */

public class SearchDataTemplate {
	
	private String status="200";
	private String side="h610n2da3rptk1vi26q9bna8k5";
	private String auth="true";
	private String message="ok";
	ArrayList<SipRtpDataCapture> data=new ArrayList<SipRtpDataCapture>();
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSide() {
		return side;
	}
	public void setSide(String side) {
		this.side = side;
	}
	public String getAuth() {
		return auth;
	}
	public void setAuth(String auth) {
		this.auth = auth;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public ArrayList<SipRtpDataCapture> getData() {
		return data;
	}
	public void setData(ArrayList<SipRtpDataCapture> data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "SearchDataTemplate [status=" + status + ", side=" + side + ", auth=" + auth + ", message=" + message
				+ ", data=" + data + "]";
	}
	
	
	
	
			

}
