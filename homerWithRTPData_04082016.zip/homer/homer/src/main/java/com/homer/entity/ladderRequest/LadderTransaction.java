package com.homer.entity.ladderRequest;

/**
 * 
 * @author 611022675
 *
 */
public class LadderTransaction {
	
	private boolean call;
	private boolean registration;
	private boolean rest;
	private boolean undefined;

	public boolean isCall() {
		return call;
	}
	public void setCall(boolean call) {
		this.call = call;
	}
	public boolean isRegistration() {
		return registration;
	}
	public void setRegistration(boolean registration) {
		this.registration = registration;
	}
	public boolean isRest() {
		return rest;
	}
	public void setRest(boolean rest) {
		this.rest = rest;
	}
	public boolean isUndefined() {
		return undefined;
	}
	public void setUndefined(boolean undefined) {
		this.undefined = undefined;
	}
	@Override
	public String toString() {
		return "LadderTransaction [call=" + call + ", registration=" + registration + ", rest=" + rest + ", undefined="
				+ undefined + "]";
	}
	
   

}
