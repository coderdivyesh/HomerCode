package com.homer.entity.ladderResponse;

import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author 611022675
 *
 */
public class Hosts {

	private Map<String,String> hosts=new HashMap<String,String>();

	public Map<String, String> getHosts() {
		return hosts;
	}

	public void setHosts(Map<String, String> hosts) {
		this.hosts = hosts;
	}

	@Override
	public String toString() {
		return "Hosts [hosts=" + hosts + "]";
	}
	
	
}
