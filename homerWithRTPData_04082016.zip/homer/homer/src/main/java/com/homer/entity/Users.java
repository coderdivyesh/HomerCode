package com.homer.entity;

import java.util.Date;

/**
 * 
 * @author 611022675
 *
 */
public class Users {
	
	
	private int UUID;
	private int GID;
	private String GRP;
	private String USERNAME;
	private String PASSWORD;
	private String FIRSTNAME;
	private String LASTNAME;
	private String EMAIL;
	private String DEPARTMENT;
	private Date REGDATE;
	private Date LASTVISIT;
	private int ACTIVE;
	
	public int getUUID() {
		return UUID;
	}
	public void setUUID(int uUID) {
		UUID = uUID;
	}
	public int getGID() {
		return GID;
	}
	public void setGID(int gID) {
		GID = gID;
	}
	public String getGRP() {
		return GRP;
	}
	public void setGRP(String gRP) {
		GRP = gRP;
	}
	public String getUSERNAME() {
		return USERNAME;
	}
	public void setUSERNAME(String uSERNAME) {
		USERNAME = uSERNAME;
	}
	public String getPASSWORD() {
		return PASSWORD;
	}
	public void setPASSWORD(String pASSWORD) {
		PASSWORD = pASSWORD;
	}
	public String getFIRSTNAME() {
		return FIRSTNAME;
	}
	public void setFIRSTNAME(String fIRSTNAME) {
		FIRSTNAME = fIRSTNAME;
	}
	public String getLASTNAME() {
		return LASTNAME;
	}
	public void setLASTNAME(String lASTNAME) {
		LASTNAME = lASTNAME;
	}
	public String getEMAIL() {
		return EMAIL;
	}
	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}
	public String getDEPARTMENT() {
		return DEPARTMENT;
	}
	public void setDEPARTMENT(String dEPARTMENT) {
		DEPARTMENT = dEPARTMENT;
	}
	public Date getREGDATE() {
		return REGDATE;
	}
	public void setREGDATE(Date rEGDATE) {
		REGDATE = rEGDATE;
	}
	public Date getLASTVISIT() {
		return LASTVISIT;
	}
	public void setLASTVISIT(Date lASTVISIT) {
		LASTVISIT = lASTVISIT;
	}
	public int getACTIVE() {
		return ACTIVE;
	}
	public void setACTIVE(int aCTIVE) {
		ACTIVE = aCTIVE;
	}
	

}
