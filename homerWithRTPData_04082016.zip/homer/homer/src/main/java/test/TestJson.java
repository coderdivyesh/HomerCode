package test;

import java.io.BufferedReader;
import java.io.FileReader;

public class TestJson {/*

public static void main(String args[]) throws Exception{
    StringBuilder buildjson=new StringBuilder();
		try (BufferedReader br = new BufferedReader(new FileReader("C:/Homer/homer/src/main/java/com/homer/common/json/getdasdBoardStore.json"))) {
		    String line;
		    while ((line = br.readLine()) != null) {
		    	buildjson.append(line);
		    }
		}
		System.out.println(buildjson);
		
}	
	
*/}
